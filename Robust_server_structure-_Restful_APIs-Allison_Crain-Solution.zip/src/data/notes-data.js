module.exports = [
  {
    id: 1,
    text: "REST stands for Representational State Transfer",
  },
  {
    id: 2,
    text: "REST maps CRUDL operations to HTTP methods",
  },
];
